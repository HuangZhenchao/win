#include "stdafx.h"

#include "FileTreeViewControl.h"


void TVW_CreateItemWnd(TREEVIEWINFO *pCtrlInfo,TreeNode<NODEDATA *> *pNode) {
	if (pNode->pFirstChild == nullptr) {
		return;
	}
	PWNDDATA *pItemData = new PWNDDATA();
	pItemData->pCtrlInfo = pCtrlInfo;
	pItemData->pExtInfo = pNode->pFirstChild;

	//rele_id_pObject.insert(map<DWORD, void*>::value_type(IDsScrollControl->dwCMID, pThis->scrollPanelControlInfo));

	DWORD dwItemID = GetIDFromPool();
	rele_id_pObject.insert(map<DWORD, void*>::value_type(dwItemID, pItemData));

	HWND hWndItem = CreateWindowEx(NULL, L"MyTreeViewItem", NULL, WS_CHILD | WS_VISIBLE,
		0, 0, 0, 0, pCtrlInfo->hWndContent, (HMENU)dwItemID, pCtrlInfo->hInstance, NULL);
	
	pNode->pFirstChild->data->hWndItem = hWndItem;

	TreeNode<NODEDATA *> *pTempNode;
	pTempNode = pNode->pFirstChild->pNextBrother;
	while (pTempNode != nullptr) {
		PWNDDATA *pItemData = new PWNDDATA();
		pItemData->pCtrlInfo = pCtrlInfo;
		pItemData->pExtInfo = pTempNode;

		//rele_id_pObject.insert(map<DWORD, void*>::value_type(IDsScrollControl->dwCMID, pThis->scrollPanelControlInfo));

		DWORD dwItemID = GetIDFromPool();
		rele_id_pObject.insert(map<DWORD, void*>::value_type(dwItemID, pItemData));

		HWND hWndItem = CreateWindowEx(NULL, L"MyTreeViewItem", NULL, WS_CHILD | WS_VISIBLE,
			0, 0, 0, 0, pCtrlInfo->hWndContent, (HMENU)dwItemID, pCtrlInfo->hInstance, NULL);
		
		pTempNode->data->hWndItem = hWndItem;

		pTempNode = pTempNode->pNextBrother;

	}
}
void RemoveData(TreeNode<NODEDATA *> *pNode) {
	if (pNode->pFirstChild==nullptr) {
		return;
	}
	TreeNode<NODEDATA *> *pTempNode;
	pTempNode = pNode->pFirstChild->pNextBrother;
	while (pTempNode != nullptr) {
		TreeNode<NODEDATA *> *pDelNode = pTempNode;

		pTempNode = pTempNode->pNextBrother;

		DWORD dItemID = GetWindowLongPtr(pDelNode->data->hWndItem, GWLP_ID);
		
		rele_id_pObject.erase(dItemID);
		PutIDToPool(dItemID);
		DestroyWindow(pDelNode->data->hWndItem);
	
		delete pDelNode;
	}
	DWORD dItemID = GetWindowLongPtr(pNode->pFirstChild->data->hWndItem, GWLP_ID);

	rele_id_pObject.erase(dItemID);
	PutIDToPool(dItemID);
	DestroyWindow(pNode->pFirstChild->data->hWndItem);

	delete pNode->pFirstChild;
	pNode->pFirstChild = nullptr;
}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
void TVW_RegisterWnd(HINSTANCE hInstance)
{
	WNDCLASSEXW wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style = 0;
	wcex.lpfnWndProc = TVWP_Control;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = sizeof(LONG);
	wcex.hInstance = hInstance;
	wcex.hIcon = NULL;
	wcex.hCursor = LoadCursor(nullptr, IDC_HAND);
	wcex.hbrBackground = CreateSolidBrush(RGB(255, 0, 0));
	wcex.lpszMenuName = NULL;
	wcex.lpszClassName = L"MyTreeViewControl";
	wcex.hIconSm = NULL;

	if (!GetClassInfoEx(hInstance, wcex.lpszClassName, &wcex)) {
		RegisterClassExW(&wcex);
	}
	wcex.lpfnWndProc = TVWP_Content;
	wcex.hbrBackground = CreateSolidBrush(RGB(255, 0, 0));
	//����ص�������ǰ������
	wcex.lpszClassName = L"MyTreeViewContent";
	if (!GetClassInfoEx(hInstance, wcex.lpszClassName, &wcex)) {
		RegisterClassExW(&wcex);
	}
	wcex.style = CS_DBLCLKS;
	wcex.lpfnWndProc = TVWP_Item;
	wcex.hbrBackground = CreateSolidBrush(RGB(255, 0, 0));
	//����ص�������ǰ������
	wcex.lpszClassName = L"MyTreeViewItem";
	if (!GetClassInfoEx(hInstance, wcex.lpszClassName, &wcex)) {
		RegisterClassExW(&wcex);
	}
	//bWndRegistered = TRUE;
}

void TraverseTree_MoveWndItem(TREEVIEWINFO *pCtrlInfo,TreeNode<NODEDATA *> *pNode) {
	if (pNode == nullptr) {
		return;
	}
	pCtrlInfo->ItemCount = pCtrlInfo->ItemCount + 1;

	//MessageBox(NULL, debugStr.c_str(), TEXT("������"), MB_OK | MB_ICONINFORMATION);
	MoveWindow(pNode->data->hWndItem, 0, (pCtrlInfo->ItemCount-1)*(pCtrlInfo->ItemHeight + 1), pCtrlInfo->MaxWidth, pCtrlInfo->ItemHeight, TRUE);
	if (pNode->data->dwExpanded>0) {
			//MessageBox(NULL, L"1", TEXT("������"), MB_OK | MB_ICONINFORMATION);
		TraverseTree_MoveWndItem(pCtrlInfo,pNode->pFirstChild);
	}
	TraverseTree_MoveWndItem(pCtrlInfo,pNode->pNextBrother);
		
}
void TraverseTree_FlushSize(TREEVIEWINFO *pCtrlInfo,TreeNode<NODEDATA *> *pNode) {
	
	if (pNode == nullptr) {
		return;
	}
	//ItemCount = ItemCount + 1;
	//MessageBox(NULL, L"������ʾ", TEXT("������"), MB_OK | MB_ICONINFORMATION);
	HDC hdc = GetDC(pCtrlInfo->hWndContent);
	HFONT hFont = CreateFontIndirect(&lfList);
	SelectObject(hdc, hFont);

	SIZE sizeTest;
	
	GetTextExtentPoint32(hdc, pNode->data->wsNodeName.c_str(), wcslen(pNode->data->wsNodeName.c_str()), &sizeTest);
	DWORD ItemWidth = pCtrlInfo->dIndent*(pNode->data->dwNodeDepth) + sizeTest.cx;//sizeTest.cx

	wstring debugStr = pNode->data->wsNodeName;
	debugStr.append(L"\n");
	wchar_t tempStr1[32];
	_itow_s(ItemWidth, tempStr1, 32);
	debugStr.append(tempStr1);

	//MessageBox(NULL, debugStr.c_str(), TEXT("������"), MB_OK | MB_ICONINFORMATION);

	if (pCtrlInfo->MaxWidth<ItemWidth) {
		pCtrlInfo->MaxWidth = ItemWidth;
	}
	pCtrlInfo->ItemHeight = sizeTest.cy;

	ReleaseDC(pCtrlInfo->hWndContent, hdc);

	if (pNode->data->dwExpanded>0) {
		//MessageBox(NULL, L"1", TEXT("������"), MB_OK | MB_ICONINFORMATION);
		TraverseTree_FlushSize(pCtrlInfo,pNode->pFirstChild);
	}
	TraverseTree_FlushSize(pCtrlInfo,pNode->pNextBrother);

}

LRESULT CALLBACK  TVWP_Control(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_CREATE:
	{
		
		PWNDDATA *pWndData = (PWNDDATA *)rele_id_pObject[(DWORD)((LPCREATESTRUCT)lParam)->hMenu];
		TREEVIEWINFO *pCtrlInfo = (TREEVIEWINFO *)pWndData->pCtrlInfo;

		pCtrlInfo->hWndControl = hWnd;
		pCtrlInfo->scrollPanelControlInfo = new SCROLLPANELCONTROLINFO();
		pCtrlInfo->scrollPanelControlInfo->dwCS = 0;
		pCtrlInfo->scrollPanelControlInfo->dwHSBAreaWidth = 5;
		pCtrlInfo->scrollPanelControlInfo->dwVSBAreaWidth = 5;

		PWNDDATA *pScrollData = new PWNDDATA();
		pScrollData->pCtrlInfo = pCtrlInfo->scrollPanelControlInfo;
		pScrollData->pExtInfo = nullptr;

		//rele_id_pObject.insert(map<DWORD, void*>::value_type(IDsScrollControl->dwCMID, pThis->scrollPanelControlInfo));

		DWORD dwScrollControlID = GetIDFromPool();
		rele_id_pObject.insert(map<DWORD, void*>::value_type(dwScrollControlID, pScrollData));

		pCtrlInfo->hWndScroll =
			CreateWindowEx(NULL, L"MyScrollPanelControl", NULL, WS_CHILD | WS_VISIBLE,
				0, 0, ((LPCREATESTRUCT)lParam)->cx, ((LPCREATESTRUCT)lParam)->cy, hWnd, (HMENU)dwScrollControlID, ((LPCREATESTRUCT)lParam)->hInstance, NULL);

		wchar_t tempStr1[32];
		_itow_s((DWORD)((LPCREATESTRUCT)lParam)->cx, tempStr1, 32);
		//MessageBox(NULL, tempStr1, TEXT("������"), MB_OK | MB_ICONINFORMATION);

		PWNDDATA *pTVContentData = new PWNDDATA();
		pTVContentData->pCtrlInfo = pCtrlInfo;
		pTVContentData->pExtInfo = nullptr;

		DWORD dwTVContentID = GetIDFromPool();
		rele_id_pObject.insert(map<DWORD, void*>::value_type(dwTVContentID, pTVContentData));

		pCtrlInfo->hWndContent =
			pCtrlInfo->scrollPanelControlInfo->hWndContent = CreateWindowEx(NULL, L"MyTreeViewContent", NULL, WS_CHILD | WS_VISIBLE,
				0, 0, 20, 30, pCtrlInfo->scrollPanelControlInfo->hWndContainer, (HMENU)dwTVContentID, ((LPCREATESTRUCT)lParam)->hInstance, NULL);

		PostMessage(hWnd, WM_USER + 11, NULL, (DWORD)SendMessage(hWndMain, WM_CUSTOM_TVN, TVN_SETROOT, dwTVContentID));

	}
	break;
	/*
	case WM_ERASEBKGND:
		return TRUE;
		*/
	case WM_SIZE:
	{
		TREEVIEWINFO *pThis = (TREEVIEWINFO *)((PWNDDATA *)rele_id_pObject[(DWORD)GetWindowLongPtr(hWnd, GWLP_ID)])->pCtrlInfo;
	}
	break;
	case WM_USER+11:
	{
		//MessageBox(NULL, L"������Ϣ����WM_USER+11", TEXT("������"), MB_OK | MB_ICONINFORMATION);
		//TREEVIEWINFO *pThis = (TREEVIEWINFO *)((PWNDDATA *)rele_id_pObject[(DWORD)GetWindowLongPtr(hWnd, GWLP_ID)])->pCtrlInfo;
		PWNDDATA *pWndData=((PWNDDATA *)rele_id_pObject[(DWORD)lParam]);
		TreeNode<NODEDATA *> *pNode = (TreeNode<NODEDATA *> *)pWndData->pExtInfo;
		TREEVIEWINFO *pCtrlInfo = (TREEVIEWINFO *)pWndData->pCtrlInfo;

		pNode->data->dwExpanded = (~pNode->data->dwExpanded) << 31 >> 31;
		wchar_t tempStr1[32];
		_itow_s(pNode->data->dwExpanded, tempStr1, 32);
		//MessageBox(NULL, tempStr1, TEXT("������"), MB_OK | MB_ICONINFORMATION);
		if ((pNode->data->dwExpanded == 1) && (pNode->data->dwHasChildren>0)) {
			//MessageBox(NULL, L"��һ���ڵ�", TEXT("������"), MB_OK | MB_ICONINFORMATION);
			//LoadData(pNode);
			if (!SendMessage(hWndMain, WM_CUSTOM_TVN, TVN_SETDATA, lParam)) {
				//MessageBox(NULL, L"����ֵ��ʲô", TEXT("������"), MB_OK | MB_ICONINFORMATION);
				TVW_CreateItemWnd(pCtrlInfo,pNode);
			}
		}
		else {
			RemoveData(pNode);
		}

		pCtrlInfo->MaxWidth = 0;
		TraverseTree_FlushSize(pCtrlInfo,pCtrlInfo->tree.pRoot);
		
		pCtrlInfo->ItemCount = 0;
		TraverseTree_MoveWndItem(pCtrlInfo,pCtrlInfo->tree.pRoot);
		
		MoveWindow(pCtrlInfo->hWndContent, 0, 0, pCtrlInfo->MaxWidth, (pCtrlInfo->ItemHeight + 1)*(pCtrlInfo->ItemCount), TRUE);
		PostMessage(pCtrlInfo->hWndScroll, WM_SIZE, NULL, NULL);
		//SendMessage(hWndMain, WM_CUSTOM_TVN, TVN_SIZE, NULL);
	}
	break;
	
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}

	return 0;
}
LRESULT CALLBACK  TVWP_Content(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_CREATE:
	{

	}
	break;
	case WM_PAINT:
	{
		
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		// TODO: �ڴ˴�����ʹ�� hdc ���κλ�ͼ����...

		EndPaint(hWnd, &ps);
	}
	break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}

	return 0;
}
LRESULT CALLBACK  TVWP_Item(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	
	switch (message)
	{
	case WM_CREATE:
	{

	}
	break;
	case WM_LBUTTONDBLCLK:
	{
		PWNDDATA *pWndData = ((PWNDDATA *)rele_id_pObject[(DWORD)GetWindowLongPtr(hWnd, GWLP_ID)]);
		TREEVIEWINFO *pCtrlInfo = (TREEVIEWINFO *)pWndData->pCtrlInfo;
		SendMessage(pCtrlInfo->hWndControl, WM_USER + 11, NULL, GetWindowLongPtr(hWnd, GWLP_ID));
	}
	break;
	case WM_PAINT:
	{
				
		PWNDDATA *pWndData = ((PWNDDATA *)rele_id_pObject[(DWORD)GetWindowLongPtr(hWnd, GWLP_ID)]);
		TREEVIEWINFO *pCtrlInfo = (TREEVIEWINFO *)pWndData->pCtrlInfo;
		TreeNode<NODEDATA*> *pNode = (TreeNode<NODEDATA*> *)pWndData->pExtInfo;

		PAINTSTRUCT ps;
		HDC hdcDebug = GetDC(hWndMain);
		RECT rcDebug;

		wchar_t tempStr1[32];
		_itow_s((DWORD)(DWORD)GetWindowLongPtr(hWnd, GWLP_ID), tempStr1, 32);
		TextOut(hdcDebug, 700, 20 * (DWORD)GetWindowLongPtr(hWnd, GWLP_ID),
			tempStr1,
			wcslen(tempStr1));
		_itow_s((DWORD)pWndData, tempStr1, 32);
		TextOut(hdcDebug, 750, 20* (DWORD)GetWindowLongPtr(hWnd, GWLP_ID),
			tempStr1,
			wcslen(tempStr1));

		_itow_s((DWORD)pNode, tempStr1, 32);
		TextOut(hdcDebug, 800, 20* (DWORD)GetWindowLongPtr(hWnd, GWLP_ID),
			tempStr1,
			wcslen(tempStr1));

		ReleaseDC(hWndMain, hdcDebug);

		HDC hdc = BeginPaint(hWnd, &ps);
		// TODO: �ڴ˴�����ʹ�� hdc ���κλ�ͼ����...

		RECT rc;
		SetRect(&rc, 0, 0, 150, 20);
		HFONT hFont = CreateFontIndirect(&lfList);
		HFONT hOldFont = (HFONT)SelectObject(hdc, hFont); //��������ѡ��Ϊ�豸�����ĵ�ǰ���壬������֮ǰ������
		//MessageBox(NULL, pNode->data->wsNodeName.c_str(), TEXT("������"), MB_OK | MB_ICONINFORMATION);
		
		TextOut(hdc, pCtrlInfo->dIndent*(pNode->data->dwNodeDepth), 0,
			pNode->data->wsNodeName.c_str(),
			wcslen(pNode->data->wsNodeName.c_str()));
		
		EndPaint(hWnd, &ps);
	}
	break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}

	return 0;
}
LRESULT CALLBACK  TVWP_Button(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{

	switch (message)
	{
	case WM_CREATE:
	{

	}
	break;
	case WM_PAINT:
	{
		PWNDDATA *pWndData = ((PWNDDATA *)rele_id_pObject[(DWORD)GetWindowLongPtr(hWnd, GWLP_ID)]);
		TREEVIEWINFO *pCtrlInfo = (TREEVIEWINFO *)pWndData->pCtrlInfo;
		TreeNode<NODEDATA> *pNode = (TreeNode<NODEDATA> *)pWndData->pExtInfo;
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		// TODO: �ڴ˴�����ʹ�� hdc ���κλ�ͼ����...

		EndPaint(hWnd, &ps);
	}
	break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}

	return 0;
}
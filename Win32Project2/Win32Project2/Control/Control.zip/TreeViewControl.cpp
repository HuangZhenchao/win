#include "stdafx.h"
#include "global.h"
#include "TreeViewControl.h"

DWORD TREEVIEWCONTROL::dwControlType = 1;
DWORD TREEVIEWCONTROL::dwCDC_1 = 1;
map<DWORD, TREEVIEWCONTROL*> TREEVIEWCONTROL::m_id_pTVC;
BOOL TREEVIEWCONTROL::bWndRegistered;

TREEVIEWCONTROL::TREEVIEWCONTROL(TREEVIEWINFO *tvInfo)
{	
	dwControlObjectID = m_id_pTVC.size() + 1;
	m_id_pTVC.insert(map<DWORD, TREEVIEWCONTROL*>::value_type(dwControlObjectID, this));

	TVInfo = tvInfo;
	wchar_t tempStr1[32];
	_itow_s((LONG)this, tempStr1, 32);
	//MessageBox(NULL, tempStr1, TEXT("������"), MB_OK | MB_ICONINFORMATION);
	//vTreeNode = TreeViewData.vTreeNode;

	if (!bWndRegistered) { TVW_RegisterWnd(); }
	DWORD dControlID = (dwControlType << 28) | (dwControlObjectID << 16);
	TVInfo->hWndControl = CreateWindowEx(NULL, L"MyTreeViewControl", NULL, WS_CHILD | WS_VISIBLE,
		0, 0, 0, 0, TVInfo->hWndParent, (HMENU)dControlID, TVInfo->hInstance, NULL);

	InitTree();
}

void TREEVIEWCONTROL::InitTree()
{
	NODEDATA NodeData;
	NodeData.wsNodeName = L"ALL";
	NodeData.wsNodePath = TVInfo->RootPath;
	NodeData.dwNodeDepth = 0;
	NodeData.dwExpanded = 0;

	NodeData.dwNodeType = 1;
	NodeData.dwHasChildren = 1;
	NodeData.dwLoadChildrenDone = 1;

	TreeNode<NODEDATA> *pRoot = new TreeNode<NODEDATA>;
	pRoot->data = NodeData;
	pRoot->pFirstChild = nullptr;
	pRoot->pNextBrother = nullptr;

	tree.SetRoot(pRoot);
	
	ExpandCollapsePath(tree.pRoot);
}
DWORD TREEVIEWCONTROL::ManageControlComponentID(DWORD *dwControlComponentIDRange_Floor, vector<DWORD> *AlternativeIDs, DWORD OperationFlag) {
	switch (OperationFlag)
	{
	case 1:
	{
		if (AlternativeIDs->size()==0) {
			DWORD tempCount=0;
			while(tempCount<20)
			{
				AlternativeIDs->push_back(*dwControlComponentIDRange_Floor + tempCount);
				tempCount++;
				
			}
			*dwControlComponentIDRange_Floor = *dwControlComponentIDRange_Floor + tempCount;
		}
		DWORD returnData = *(AlternativeIDs->end() - 1);
			//[AlternativeIDs->size() - 1];
		AlternativeIDs->pop_back();
		return returnData;
	}
	break;
	case 2:
		AlternativeIDs->push_back(*dwControlComponentIDRange_Floor);
		return 1;
	default:
		break;
	}
	return 0;
}

DWORD TREEVIEWCONTROL::LoadData(TreeNode<NODEDATA> *pNode)
{
	vector<WIN32_FIND_DATA> ChildNodeList;
	FINDFILEPARAM *FindFileParam = new FINDFILEPARAM();
	FindFileParam->dwFileFloderFlag = 0x00000011;
	FindFileParam->szFileDirectory = pNode->data.wsNodePath;

	ChildNodeList = FileSystem::FindFile(FindFileParam);
	for (vector<WIN32_FIND_DATA>::iterator iter = ChildNodeList.begin(); iter != ChildNodeList.end(); iter++)
	{
		NODEDATA NodeData;
		NodeData.wsNodeName = iter->cFileName;
		//��ȡ���ݺ�ѭ��������
		//�ٻ�ȡ�ӽڵ��Ƿ�������
		wstring temStr = pNode->data.wsNodePath;
		temStr.append(L"\\");
		temStr.append(iter->cFileName);

		if (iter->dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY) {
			NodeData.dwNodeType = 1;
			NodeData.dwIconType = 1;
			NodeData.dwHasChildren = 1;

		}

		NodeData.wsNodePath = temStr;
		NodeData.dwNodeDepth = pNode->data.dwNodeDepth + 1;

		TreeNode<NODEDATA> *pNewNode = new TreeNode<NODEDATA>;
		pNewNode->data = NodeData;
		pNewNode->pFirstChild = nullptr;
		pNewNode->pNextBrother = nullptr;

		tree.InsertNode(pNode, pNewNode);
		//�ڲ����ID�����ID�����ݹ���
		DWORD dwCDC_1_ID = ManageControlComponentID(&dwCDC_1_FloorID,&vCDC_1_AlternativeIDs,1);
		
		DWORD dwWndID = (dwControlType << 28) | (dwControlObjectID << 16) | (dwCDC_1 << 12) | dwCDC_1_ID;
		HDC hdc = GetDC(TVInfo->hWndControl);
		HFONT hFont = CreateFontIndirect(&lfList);
		SelectObject(hdc, hFont);
		HWND hWndItem = CreateWindowEx(NULL, L"MyTreeViewItem", NULL, WS_CHILD | WS_VISIBLE ,
			0, 0, 0, 0, TVInfo->hWndControl, (HMENU)dwWndID, TVInfo->hInstance, NULL);
		SIZE sizeTest;
		GetTextExtentPoint32(hdc, pNewNode->data->wsNodeName, wcslen(vTVInfo[tvID].ft.vTreeNode[i]->data.FileData.cFileName), &sizeTest);
		DWORD ItemWidth = vTVInfo[tvID].ft.dIndent*(vTVInfo[tvID].ft.vTreeNode[i]->data.depth - 1) + sizeTest.cx;//sizeTest.cx
		if (TVInfo.MaxItemWidth<ItemWidth) {
			TVInfo.MaxItemWidth = ItemWidth;
		}
		TVInfo.ItemHeight = sizeTest.cy;
	
		ReleaseDC(hScrollCtrl.hWnd_Content, hdc);
		
		m_HWND_TreeNode.insert(map<DWORD, TreeNode<NODEDATA> * >::value_type(dwCDC_1_ID, pNewNode));
		pNewNode->data.hWndItem = hWndItem;
	}
	return ChildNodeList.size();
}

void TREEVIEWCONTROL::RemoveData(TreeNode<NODEDATA> *pNode) {
	if (pNode->pFirstChild==nullptr) {
		return;
	}
	TreeNode<NODEDATA> *pTempNode;
	pTempNode = pNode->pFirstChild->pNextBrother;
	while (pTempNode != nullptr) {
		TreeNode<NODEDATA> *pDelNode = pTempNode;

		pTempNode = pTempNode->pNextBrother;

		DWORD dControlID = GetWindowLongPtr(pDelNode->data.hWndItem, GWLP_ID);
		DWORD v_id = (dControlID << 20) >> 20;
		m_HWND_TreeNode.erase(v_id);
		ManageControlComponentID(&v_id, &vCDC_1_AlternativeIDs, 2);
		DestroyWindow(pDelNode->data.hWndItem);
	
		delete pDelNode;
	}
	DWORD dControlID = GetWindowLongPtr(pNode->pFirstChild->data.hWndItem, GWLP_ID);
	DWORD v_id = (dControlID << 20) >> 20;
	m_HWND_TreeNode.erase(v_id);
	ManageControlComponentID(&v_id, &vCDC_1_AlternativeIDs, 2);
	DestroyWindow(pNode->pFirstChild->data.hWndItem);

	delete pNode->pFirstChild;
	pNode->pFirstChild = nullptr;
}
void TREEVIEWCONTROL::ExpandCollapsePath(TreeNode<NODEDATA> *pNode)
{
	pNode->data.dwExpanded = (~pNode->data.dwExpanded) << 31 >> 31;
	wchar_t tempStr1[32];
	_itow_s(pNode->data.dwExpanded, tempStr1, 32);
	//MessageBox(NULL, tempStr1, TEXT("������"), MB_OK | MB_ICONINFORMATION);
	if ((pNode->data.dwExpanded == 1) && (pNode->data.dwHasChildren>0)) {
		//MessageBox(NULL, L"��һ���ڵ�", TEXT("������"), MB_OK | MB_ICONINFORMATION);
		LoadData(pNode);
		/*
		if (pNode->pFirstChild != nullptr) {
			pNode->pFirstChild->data.dwHasChildren = LoadData(pNode->pFirstChild);
			pNode->pFirstChild->data.dwLoadChildrenDone = 1;
			TreeNode<NODEDATA> *pTempNode;
			pTempNode = pNode->pFirstChild->pNextBrother;
			while (pTempNode != nullptr) {
				pTempNode->data.dwHasChildren = LoadData(pTempNode);
				pTempNode->data.dwLoadChildrenDone = 1;
				pTempNode = pTempNode->pNextBrother;
			}
		}
		*/
	}
	else {
		RemoveData(pNode);
	}
	//vector<TreeNode<NODEDATA> *>().swap(vTreeNode);
	//TreeToVector(tree.pRoot);
	ItemCount = 0;
	TVD2W_TraverseTree(tree.pRoot);
	
	MoveWindow(TVInfo->hWndControl,0,0, TVInfo->MaxWidth, (TVInfo->ItemHeight+1)*(ItemCount),TRUE);
}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  

void TREEVIEWCONTROL::TVW_RegisterWnd()
{
	WNDCLASSEXW wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style = 0;
	wcex.lpfnWndProc = DefWindowProc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = sizeof(LONG);
	wcex.hInstance = TVInfo->hInstance;
	wcex.hIcon = NULL;
	wcex.hCursor = LoadCursor(nullptr, IDC_HAND);
	wcex.hbrBackground = CreateSolidBrush(RGB(255, 0, 0));
	wcex.lpszMenuName = NULL;
	wcex.lpszClassName = L"MyTreeViewControl";
	wcex.hIconSm = NULL;

	if (!GetClassInfoEx(TVInfo->hInstance, wcex.lpszClassName, &wcex)) {
		RegisterClassExW(&wcex);
	}
	wcex.style = CS_DBLCLKS;
	wcex.lpfnWndProc = TVWP_Item;
	wcex.hbrBackground = CreateSolidBrush(RGB(255, 0, 0));
	//����ص�������ǰ������
	wcex.lpszClassName = L"MyTreeViewItem";
	if (!GetClassInfoEx(TVInfo->hInstance, wcex.lpszClassName, &wcex)) {
		RegisterClassExW(&wcex);
	}
	bWndRegistered = TRUE;
}

void TREEVIEWCONTROL::TVD2W_TraverseTree(TreeNode<NODEDATA> *pNode) {
	if (pNode == nullptr) {
		return;
	}
	ItemCount = ItemCount + 1;
	
	wstring debugStr= pNode->data.wsNodeName;
	debugStr.append(L"\n");
	wchar_t tempStr1[32];
	_itow_s(ItemCount, tempStr1, 32);
	debugStr.append(tempStr1);
	
	//MessageBox(NULL, debugStr.c_str(), TEXT("������"), MB_OK | MB_ICONINFORMATION);
	
	MoveWindow(pNode->data.hWndItem, 0, (ItemCount-1)*(TVInfo->ItemHeight + 1), TVInfo->MaxWidth, TVInfo->ItemHeight, TRUE);
	if (pNode->data.dwExpanded>0) {
			//MessageBox(NULL, L"1", TEXT("������"), MB_OK | MB_ICONINFORMATION);
		TVD2W_TraverseTree(pNode->pFirstChild);
	}
	TVD2W_TraverseTree(pNode->pNextBrother);
		
}

LRESULT CALLBACK  TREEVIEWCONTROL::TVWP_Control(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{

	switch (message)
	{
	case WM_CREATE:
	{

	}
	break;
	/*
	case WM_ERASEBKGND:
		return TRUE;
		*/
	case WM_SIZE:
	{
		DWORD dwWndID = GetWindowLongPtr(hWnd, GWLP_ID);
		DWORD map_id = (dwWndID << 4) >> 20;
		TREEVIEWCONTROL *pThis = m_id_pTVC[map_id];

		//DWORD index = 0;
		//for (vector<HWND>::iterator iter = pThis->vHWNDItem.begin(); iter != pThis->vHWNDItem.end(); iter++) {
		//	MoveWindow(*iter, 0, index*(pThis->ItemHeight + 1), pThis->MaxWidth, pThis->ItemHeight, TRUE);
		//	index++;
		//}
		//pThis->TVD2W_TraverseTree(pThis->tree.pRoot,0,TRUE);
	}
	break;
	case WM_PAINT:
	{
		DWORD dwWndID = GetWindowLongPtr(hWnd, GWLP_ID);
		DWORD map_id = (dwWndID << 4) >> 20;
		TREEVIEWCONTROL *pThis = m_id_pTVC[map_id];
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		// TODO: �ڴ˴�����ʹ�� hdc ���κλ�ͼ����...

		EndPaint(hWnd, &ps);
	}
	break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}

	return 0;
}
LRESULT CALLBACK  TREEVIEWCONTROL::TVWP_Item(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{

	switch (message)
	{
	case WM_CREATE:
	{

	}
	break;
	case WM_LBUTTONDBLCLK:
	{
		DWORD dwWndID = GetWindowLongPtr(hWnd, GWLP_ID);
		DWORD map_id = (dwWndID << 4) >> 20;
		DWORD v_id = (dwWndID << 20) >> 20;
		//wchar_t tempStr1[32];
		//_itow_s(map_id, tempStr1, 32);
		//MessageBox(NULL, L"˫��", TEXT("������"), MB_OK | MB_ICONINFORMATION);
		TREEVIEWCONTROL *pThis = (TREEVIEWCONTROL*)m_id_pTVC[map_id];
		pThis->ExpandCollapsePath(pThis->m_HWND_TreeNode[v_id]);
		//pThis->CreateTreeViewItem();
	}
	break;
	case WM_PAINT:
	{
		DWORD dwWndID = GetWindowLongPtr(hWnd, GWLP_ID);
		DWORD map_id = (dwWndID << 4) >> 20;
		DWORD v_id = (dwWndID << 20) >> 20;
		//wchar_t tempStr1[32];
		//_itow_s(map_id, tempStr1, 32);
		//MessageBox(NULL, tempStr1, TEXT("������"), MB_OK | MB_ICONINFORMATION);
		TREEVIEWCONTROL *pThis = (TREEVIEWCONTROL*)m_id_pTVC[map_id];
		PAINTSTRUCT ps;
		HDC hdcDebug = GetDC(hWndMain);
		RECT rcDebug;
		SetRect(&rcDebug, 200, 20, 150, 20);
		wchar_t tempStr1[32];
		_itow_s((LONG)pThis, tempStr1, 32);
		TextOut(hdcDebug, 200, 0, tempStr1, wcslen(tempStr1));//wcslen(tempStr1)

		ReleaseDC(hWndMain, hdcDebug);

		HDC hdc = BeginPaint(hWnd, &ps);
		// TODO: �ڴ˴�����ʹ�� hdc ���κλ�ͼ����...

		RECT rc;
		SetRect(&rc, 0, 0, 150, 20);
		HFONT hFont = CreateFontIndirect(&lfList);
		HFONT hOldFont = (HFONT)SelectObject(hdc, hFont); //��������ѡ��Ϊ�豸�����ĵ�ǰ���壬������֮ǰ������
														  //MessageBox(NULL, tempStr1, TEXT("������"), MB_OK | MB_ICONINFORMATION);
		TextOut(hdc, pThis->TVInfo->dIndent*(pThis->m_HWND_TreeNode[v_id]->data.dwNodeDepth), 0,
			pThis->m_HWND_TreeNode[v_id]->data.wsNodeName.c_str(),
			wcslen(pThis->m_HWND_TreeNode[v_id]->data.wsNodeName.c_str()));
		//pThis->TVStyle.dIndent*(pThis->TreeViewData.vTreeNode[v_id]->data.dNodeDepth)
		//pThis->TreeViewData.vTreeNode[v_id]->data.NodeName.c_str()
		//pThis->TreeViewData.vTreeNode[v_id]->data.NodeName.c_str()
		EndPaint(hWnd, &ps);
	}
	break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}

	return 0;
}
LRESULT CALLBACK  TREEVIEWCONTROL::TVWP_Button(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{

	switch (message)
	{
	case WM_CREATE:
	{

	}
	break;
	case WM_PAINT:
	{
		DWORD dControlID = GetWindowLongPtr(hWnd, GWLP_ID);
		DWORD map_id = (dControlID << 4) >> 20;
		TREEVIEWCONTROL *pThis = m_id_pTVC[map_id];
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		// TODO: �ڴ˴�����ʹ�� hdc ���κλ�ͼ����...

		EndPaint(hWnd, &ps);
	}
	break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}

	return 0;
}